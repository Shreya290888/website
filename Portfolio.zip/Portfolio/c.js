window.onload = function() {
  setTimeout(function() {
      document.getElementById("splash-screen").style.display = "none";
      document.getElementById("main-content").style.display = "block";
  }, 3000); // 3 seconds duration
};
